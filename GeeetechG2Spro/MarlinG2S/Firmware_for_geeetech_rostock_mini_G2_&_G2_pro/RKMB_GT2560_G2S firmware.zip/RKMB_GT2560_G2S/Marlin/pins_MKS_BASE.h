/**
 * MKS BASE 1.0 – Arduino Mega2560 with RAMPS v1.4 pin assignments
 */

#define IS_RAMPS_EFB

#include "pins_RAMPS_13.h"

#undef HEATER_1_PIN
#define HEATER_1_PIN        7
