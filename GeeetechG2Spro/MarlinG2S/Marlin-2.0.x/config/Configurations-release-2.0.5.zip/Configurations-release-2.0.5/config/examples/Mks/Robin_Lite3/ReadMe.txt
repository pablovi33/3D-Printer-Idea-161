1. MKS Robin Lite3 is a powerful 32-bit 3D printer control board with STM32F103RCT6.
2. Support Marlin2.0.
3. Support MKS LCD12864B/MINI12864/LCD2004/12864 and MKS TFT Touch Screens.
4. The main board integrates 5 AXIS interface, BLTOUCH interface, hot bed, 2 heating heads, 3 NTC100K and LCD screen SD card supports firmware update.
https://www.aliexpress.com/item/4000295949948.html?spm=2114.12010615.8148356.1.596183361yB18D
